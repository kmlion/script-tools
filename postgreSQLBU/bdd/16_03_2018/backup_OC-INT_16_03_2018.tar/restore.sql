--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."User" DROP CONSTRAINT "Fkey_User_Package_id";
ALTER TABLE ONLY public."Package" DROP CONSTRAINT "Fkey_User_Owner";
ALTER TABLE ONLY public."Package_FilterPackage" DROP CONSTRAINT "Fkey_Package_FilterPackage_Package";
ALTER TABLE ONLY public."Package_FilterPackage" DROP CONSTRAINT "Fkey_Package_FilterPackage_FilterPackage";
ALTER TABLE ONLY public."Package_AlertCustom" DROP CONSTRAINT "Fkey_PackageAlertCustom_Package";
ALTER TABLE ONLY public."Package_AlertCustom" DROP CONSTRAINT "Fkey_PackageAlertCustom_AlertCustom";
ALTER TABLE ONLY public."FilterPackage" DROP CONSTRAINT "Fkey_FilterPackage_FilterType";
ALTER TABLE ONLY public."User" DROP CONSTRAINT "User_pkey";
ALTER TABLE ONLY public."Package_FilterPackage" DROP CONSTRAINT "Pkey_Package_FilterPackage";
ALTER TABLE ONLY public."Package_AlertCustom" DROP CONSTRAINT "Pkey_Package_AlertCustom";
ALTER TABLE ONLY public."FilterType" DROP CONSTRAINT "Pkey_FilterType";
ALTER TABLE ONLY public."Package" DROP CONSTRAINT "Package_pkey";
ALTER TABLE ONLY public."FilterPackage" DROP CONSTRAINT "FilterPackage_pkey";
ALTER TABLE ONLY public."AlertCustom" DROP CONSTRAINT "AlertsPerUser_pkey";
DROP TABLE public."Package_FilterPackage";
DROP VIEW public."PackageDetail";
DROP TABLE public."User";
DROP TABLE public."Package_AlertCustom";
DROP TABLE public."Package";
DROP TABLE public."FilterType";
DROP TABLE public."FilterPackage";
DROP TABLE public."AlertCustom";
DROP EXTENSION "uuid-ossp";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: AlertCustom; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "AlertCustom" (
    "Id" uuid DEFAULT uuid_generate_v4() NOT NULL,
    "Name" text NOT NULL,
    "AlertsCategory" smallint NOT NULL,
    "TimelineCategory" smallint NOT NULL,
    "Description" text NOT NULL,
    "Dataset" smallint NOT NULL,
    "DefaultRule" text NOT NULL,
    "ActiveRule" text NOT NULL,
    "UserNG" text,
    "AccessLevel" smallint,
    "LastUpdated" date
);


ALTER TABLE "AlertCustom" OWNER TO postgres;

--
-- Name: FilterPackage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "FilterPackage" (
    "Id" uuid DEFAULT uuid_generate_v4() NOT NULL,
    "FilterType_id" integer,
    "Value" text
);


ALTER TABLE "FilterPackage" OWNER TO postgres;

--
-- Name: FilterType; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "FilterType" (
    "Id" bigint NOT NULL,
    "Type" text
);


ALTER TABLE "FilterType" OWNER TO postgres;

--
-- Name: Package; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "Package" (
    "Id" uuid DEFAULT uuid_generate_v4() NOT NULL,
    "Name" text NOT NULL,
    "Description" text NOT NULL,
    "Owner" text NOT NULL,
    "Share" boolean NOT NULL,
    "LastUpdated" date NOT NULL
);


ALTER TABLE "Package" OWNER TO postgres;

--
-- Name: Package_AlertCustom; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "Package_AlertCustom" (
    "Package_id" uuid NOT NULL,
    "AlertCustom_id" uuid NOT NULL
);


ALTER TABLE "Package_AlertCustom" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "User" (
    "Id" uuid DEFAULT uuid_generate_v4() NOT NULL,
    "Account" text,
    "UserName" text,
    "IdaasIdentifier" text NOT NULL,
    "OpenIdName" text,
    "AICorporateID" text,
    "Country" text,
    "ContactEmail" text,
    "AirbusEmail" text,
    "AiPrincipleName" text,
    "GroupID" text,
    "PackageID" uuid
);


ALTER TABLE "User" OWNER TO postgres;

--
-- Name: PackageDetail; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW "PackageDetail" AS
 SELECT "Package"."Id",
    "Package"."Name",
    "Package"."Description",
    "Package"."Owner",
    "Package"."LastUpdated",
    "Package"."Share",
    a."AlertNumber",
    c."UserNumber"
   FROM (("Package"
     LEFT JOIN ( SELECT "Package_AlertCustom"."Package_id",
            count("Package_AlertCustom"."AlertCustom_id") AS "AlertNumber"
           FROM "Package_AlertCustom"
          GROUP BY "Package_AlertCustom"."Package_id") a ON (("Package"."Id" = a."Package_id")))
     LEFT JOIN ( SELECT "User"."PackageID",
            count("User"."Id") AS "UserNumber"
           FROM "User"
          GROUP BY "User"."PackageID") c ON (("Package"."Id" = c."PackageID")));


ALTER TABLE "PackageDetail" OWNER TO postgres;

--
-- Name: Package_FilterPackage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "Package_FilterPackage" (
    "Package_id" uuid NOT NULL,
    "FilterPackage_id" uuid NOT NULL
);


ALTER TABLE "Package_FilterPackage" OWNER TO postgres;

--
-- Data for Name: AlertCustom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "AlertCustom" ("Id", "Name", "AlertsCategory", "TimelineCategory", "Description", "Dataset", "DefaultRule", "ActiveRule", "UserNG", "AccessLevel", "LastUpdated") FROM stdin;
\.
COPY "AlertCustom" ("Id", "Name", "AlertsCategory", "TimelineCategory", "Description", "Dataset", "DefaultRule", "ActiveRule", "UserNG", "AccessLevel", "LastUpdated") FROM '$$PATH$$/2058.dat';

--
-- Data for Name: FilterPackage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "FilterPackage" ("Id", "FilterType_id", "Value") FROM stdin;
\.
COPY "FilterPackage" ("Id", "FilterType_id", "Value") FROM '$$PATH$$/2062.dat';

--
-- Data for Name: FilterType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "FilterType" ("Id", "Type") FROM stdin;
\.
COPY "FilterType" ("Id", "Type") FROM '$$PATH$$/2059.dat';

--
-- Data for Name: Package; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Package" ("Id", "Name", "Description", "Owner", "Share", "LastUpdated") FROM stdin;
\.
COPY "Package" ("Id", "Name", "Description", "Owner", "Share", "LastUpdated") FROM '$$PATH$$/2061.dat';

--
-- Data for Name: Package_AlertCustom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Package_AlertCustom" ("Package_id", "AlertCustom_id") FROM stdin;
\.
COPY "Package_AlertCustom" ("Package_id", "AlertCustom_id") FROM '$$PATH$$/2063.dat';

--
-- Data for Name: Package_FilterPackage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Package_FilterPackage" ("Package_id", "FilterPackage_id") FROM stdin;
\.
COPY "Package_FilterPackage" ("Package_id", "FilterPackage_id") FROM '$$PATH$$/2064.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "User" ("Id", "Account", "UserName", "IdaasIdentifier", "OpenIdName", "AICorporateID", "Country", "ContactEmail", "AirbusEmail", "AiPrincipleName", "GroupID", "PackageID") FROM stdin;
\.
COPY "User" ("Id", "Account", "UserName", "IdaasIdentifier", "OpenIdName", "AICorporateID", "Country", "ContactEmail", "AirbusEmail", "AiPrincipleName", "GroupID", "PackageID") FROM '$$PATH$$/2060.dat';

--
-- Name: AlertsPerUser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "AlertCustom"
    ADD CONSTRAINT "AlertsPerUser_pkey" PRIMARY KEY ("Id");


--
-- Name: FilterPackage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "FilterPackage"
    ADD CONSTRAINT "FilterPackage_pkey" PRIMARY KEY ("Id");


--
-- Name: Package_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Package"
    ADD CONSTRAINT "Package_pkey" PRIMARY KEY ("Id");


--
-- Name: Pkey_FilterType; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "FilterType"
    ADD CONSTRAINT "Pkey_FilterType" PRIMARY KEY ("Id");


--
-- Name: Pkey_Package_AlertCustom; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Package_AlertCustom"
    ADD CONSTRAINT "Pkey_Package_AlertCustom" PRIMARY KEY ("Package_id", "AlertCustom_id");


--
-- Name: Pkey_Package_FilterPackage; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Package_FilterPackage"
    ADD CONSTRAINT "Pkey_Package_FilterPackage" PRIMARY KEY ("Package_id", "FilterPackage_id");


--
-- Name: User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY ("IdaasIdentifier");


--
-- Name: Fkey_FilterPackage_FilterType; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "FilterPackage"
    ADD CONSTRAINT "Fkey_FilterPackage_FilterType" FOREIGN KEY ("FilterType_id") REFERENCES "FilterType"("Id") ON DELETE CASCADE;


--
-- Name: Fkey_PackageAlertCustom_AlertCustom; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Package_AlertCustom"
    ADD CONSTRAINT "Fkey_PackageAlertCustom_AlertCustom" FOREIGN KEY ("AlertCustom_id") REFERENCES "AlertCustom"("Id") ON DELETE CASCADE;


--
-- Name: Fkey_PackageAlertCustom_Package; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Package_AlertCustom"
    ADD CONSTRAINT "Fkey_PackageAlertCustom_Package" FOREIGN KEY ("Package_id") REFERENCES "Package"("Id") ON DELETE CASCADE;


--
-- Name: Fkey_Package_FilterPackage_FilterPackage; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Package_FilterPackage"
    ADD CONSTRAINT "Fkey_Package_FilterPackage_FilterPackage" FOREIGN KEY ("FilterPackage_id") REFERENCES "FilterPackage"("Id") ON DELETE CASCADE;


--
-- Name: Fkey_Package_FilterPackage_Package; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Package_FilterPackage"
    ADD CONSTRAINT "Fkey_Package_FilterPackage_Package" FOREIGN KEY ("Package_id") REFERENCES "Package"("Id") ON DELETE CASCADE;


--
-- Name: Fkey_User_Owner; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Package"
    ADD CONSTRAINT "Fkey_User_Owner" FOREIGN KEY ("Owner") REFERENCES "User"("IdaasIdentifier") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Fkey_User_Package_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "User"
    ADD CONSTRAINT "Fkey_User_Package_id" FOREIGN KEY ("PackageID") REFERENCES "Package"("Id");


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO readonly_user;
GRANT USAGE ON SCHEMA public TO readwrite_user;
GRANT USAGE ON SCHEMA public TO qlik_user;


--
-- PostgreSQL database dump complete
--

